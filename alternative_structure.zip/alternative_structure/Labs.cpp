#include "Labs.h"

void Labs::lab_1() {
	int x = 0;
	double y = 42.5;
	bool Answer = false;
	x = x + 19;
	x = x + 9.5;
	int xx = 100;
	int int_number = 4;
	float float_number = 4.4;

	cout << "The value of x is " << x << endl;
	cout << "This is a section of text." << " And this is another" << endl;
	cout << "The value of y is " << y << endl;
	cout << "The value of Answer is " << Answer << endl;
	cout << "The xalue of xx is " << xx << endl;
	cout << formula(6, 4, 7, 2, 3) << endl;
	cout << int_number + float_number << endl;
	cout << int_number + 4.5 << endl;
	cout << BMI(50, 1.65);
}



void Labs::lab_2() {

}
