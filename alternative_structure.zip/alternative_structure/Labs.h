#pragma once

#include <iostream>

using namespace std;

class Labs
{
public:
	void lab_1();
	void lab_2();

private:
	static float formula(int a, int b, int c, int d, int y) {
		float x;
		x = y + (static_cast<float>(a) + b) * 2 / (c - d);
		return x;
	}

	static float BMI(float weight, float height) {
		return weight / (height * height);
	}
};

