// Lab1.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include "Labs.h"
using namespace std;


// This is the main function
int main()
{
	Labs lab;
	lab.lab_1();

	lab.lab_2();

}